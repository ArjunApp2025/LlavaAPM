import React from 'react';
import { Station } from '../types';
import { StationWaitingData, getStationWaitingData } from '../mockData';

interface StationModalProps {
  station: Station | null;
  onClose: () => void;
}

export const StationModal: React.FC<StationModalProps> = ({ station, onClose }) => {
  if (!station) return null;

  const waitingData: StationWaitingData = getStationWaitingData(station.id);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={onClose}>
      <div 
        className="bg-white rounded-lg p-6 max-w-md w-full mx-4 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-gray-900">{station.name}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl font-bold"
          >
            ×
          </button>
        </div>

        <div className="space-y-4">
          {/* Camera Feed Status */}
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${
              waitingData.cameraFeedStatus === 'active' ? 'bg-green-500' : 'bg-red-500'
            }`}></div>
            <span className="text-sm text-gray-600">
              Camera Feed: {waitingData.cameraFeedStatus === 'active' ? 'Active' : 'Offline'}
            </span>
          </div>

          {/* Waiting Count */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="text-sm text-gray-600 mb-1">People Waiting</div>
            <div className="text-4xl font-bold text-blue-700">
              {waitingData.waitingCount}
            </div>
            <div className="text-xs text-gray-500 mt-2">
              Last updated: {waitingData.lastUpdated.toLocaleTimeString()}
            </div>
          </div>

          {/* Info */}
          <div className="text-xs text-gray-500 bg-gray-50 p-3 rounded">
            <p>
              <strong>Data Source:</strong> Camera feed analysis using computer vision
            </p>
            <p className="mt-1">
              This count represents the number of people detected waiting at the platform.
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-6 w-full px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium"
        >
          Close
        </button>
      </div>
    </div>
  );
};


