import React from 'react';
import { KPIValues } from '../types';

interface KPIStripProps {
  kpis: KPIValues;
}

export const KPIStrip: React.FC<KPIStripProps> = ({ kpis }) => {
  const kpiCards = [
    {
      label: 'Average Headway',
      value: `${kpis.averageHeadway.toFixed(1)} min`,
      icon: '⏱️',
      color: 'bg-blue-50 border-blue-200 text-blue-700',
    },
    {
      label: 'Trains in Service',
      value: kpis.trainsInService.toString(),
      icon: '🚇',
      color: 'bg-green-50 border-green-200 text-green-700',
    },
    {
      label: 'On-Time Performance',
      value: `${kpis.overallOnTimePerformance.toFixed(1)}%`,
      icon: '✅',
      color: 'bg-purple-50 border-purple-200 text-purple-700',
    },
    {
      label: 'Average Load',
      value: `${kpis.averageLoad.toFixed(1)}%`,
      icon: '📊',
      color: 'bg-amber-50 border-amber-200 text-amber-700',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {kpiCards.map((card, index) => (
        <div
          key={index}
          className={`${card.color} border border-gray-200/60 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-2xl">{card.icon}</span>
            <span className="text-3xl font-bold tracking-tight">{card.value}</span>
          </div>
          <div className="text-xs font-semibold text-gray-600 uppercase tracking-wide">{card.label}</div>
        </div>
      ))}
    </div>
  );
};

