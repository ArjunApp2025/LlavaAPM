import React, { useState, useMemo } from 'react';
import { Train, FilterState } from '../types';
import { getTrainLoadPercentage } from '../mockData';

interface TrainTableProps {
  trains: Train[];
  filters: FilterState;
}

type SortField = 'load' | 'eta' | null;
type SortDirection = 'asc' | 'desc';

export const TrainTable: React.FC<TrainTableProps> = ({ trains, filters }) => {
  const [sortField, setSortField] = useState<SortField>(null);
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  // Filter trains
  const filteredTrains = useMemo(() => {
    let filtered = [...trains];

    if (filters.direction !== 'All') {
      filtered = filtered.filter(t => t.direction === filters.direction);
    }

    if (filters.segment !== 'All') {
      filtered = filtered.filter(t => t.currentSegment === filters.segment);
    }

    return filtered;
  }, [trains, filters]);

  // Sort trains
  const sortedTrains = useMemo(() => {
    if (!sortField) return filteredTrains;

    const sorted = [...filteredTrains].sort((a, b) => {
      let aValue: number;
      let bValue: number;

      if (sortField === 'load') {
        aValue = getTrainLoadPercentage(a);
        bValue = getTrainLoadPercentage(b);
      } else {
        aValue = a.etaToNextStop;
        bValue = b.etaToNextStop;
      }

      if (sortDirection === 'asc') {
        return aValue - bValue;
      } else {
        return bValue - aValue;
      }
    });

    return sorted;
  }, [filteredTrains, sortField, sortDirection]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return '↕️';
    return sortDirection === 'asc' ? '↑' : '↓';
  };

  return (
    <div className="bg-white border border-gray-200/60 rounded-2xl p-6 shadow-sm">
      <h2 className="text-lg font-semibold mb-6 text-gray-900 tracking-tight">Train Status</h2>
      
      <div className="overflow-x-auto -mx-6 px-6">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200/60">
              <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Train ID</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Current Location</th>
              <th 
                className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer hover:bg-gray-50/50 rounded-lg transition-colors"
                onClick={() => handleSort('load')}
              >
                Load % {getSortIcon('load')}
              </th>
              <th 
                className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer hover:bg-gray-50/50 rounded-lg transition-colors"
                onClick={() => handleSort('eta')}
              >
                ETA (min) {getSortIcon('eta')}
              </th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Next Stop</th>
            </tr>
          </thead>
          <tbody>
            {sortedTrains.map((train) => {
              const loadPercentage = getTrainLoadPercentage(train);
              const isOverloaded = loadPercentage > 90;
              
              return (
                <tr
                  key={train.id}
                  className={`border-b border-gray-100/60 hover:bg-gray-50/50 transition-colors ${
                    isOverloaded ? 'bg-red-50/30' : ''
                  }`}
                >
                  <td className="py-3 px-4 font-semibold text-gray-900">{train.id}</td>
                  <td className="py-3 px-4 text-gray-700 font-medium">
                    {train.currentStation || train.currentSegment}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className={`font-semibold ${
                        loadPercentage > 80 ? 'text-red-600' : 
                        loadPercentage > 50 ? 'text-amber-600' : 
                        'text-green-600'
                      }`}>
                        {loadPercentage.toFixed(1)}%
                      </span>
                      {isOverloaded && (
                        <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-lg font-medium">
                          Overloaded
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-gray-700 font-medium">{train.etaToNextStop}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                      train.status === 'On Time' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {train.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-700 font-medium">{train.nextStop}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      
      {sortedTrains.length === 0 && (
        <div className="text-center py-12 text-gray-400 text-sm font-medium">
          No trains match the current filters.
        </div>
      )}
    </div>
  );
};

