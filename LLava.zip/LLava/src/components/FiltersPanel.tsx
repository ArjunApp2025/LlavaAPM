import React from 'react';
import { FilterState, Direction } from '../types';
import { SEGMENTS } from '../mockData';

interface FiltersPanelProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
}

export const FiltersPanel: React.FC<FiltersPanelProps> = ({ filters, onFilterChange }) => {
  const handleTimeRangeChange = (timeRange: '30min' | '1hr' | '4hr') => {
    onFilterChange({ ...filters, timeRange });
  };

  const handleDirectionChange = (direction: Direction | 'All') => {
    onFilterChange({ ...filters, direction });
  };

  const handleSegmentChange = (segment: string) => {
    onFilterChange({ ...filters, segment });
  };

  return (
    <div className="bg-white border border-gray-200/60 rounded-2xl p-6 shadow-sm h-full">
      <h2 className="text-lg font-semibold mb-6 text-gray-900 tracking-tight">Filters</h2>
      
      {/* Time Range */}
      <div className="mb-8">
        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">
          Time Range
        </label>
        <div className="space-y-2">
          {(['30min', '1hr', '4hr'] as const).map((range) => (
            <label 
              key={range} 
              className={`flex items-center px-3 py-2.5 rounded-xl cursor-pointer transition-all ${
                filters.timeRange === range 
                  ? 'bg-blue-50 border-2 border-blue-500' 
                  : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
              }`}
            >
              <input
                type="radio"
                name="timeRange"
                value={range}
                checked={filters.timeRange === range}
                onChange={() => handleTimeRangeChange(range)}
                className="mr-3 w-4 h-4 text-blue-600 focus:ring-2 focus:ring-blue-500"
              />
              <span className={`text-sm font-medium ${
                filters.timeRange === range ? 'text-blue-900' : 'text-gray-700'
              }`}>
                {range === '30min' ? 'Last 30 min' : range === '1hr' ? 'Last 1 hr' : 'Last 4 hr'}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Direction */}
      <div className="mb-8">
        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">
          Direction
        </label>
        <div className="space-y-2">
          {(['All', 'Inbound', 'Outbound'] as const).map((dir) => (
            <label 
              key={dir} 
              className={`flex items-center px-3 py-2.5 rounded-xl cursor-pointer transition-all ${
                filters.direction === dir 
                  ? 'bg-blue-50 border-2 border-blue-500' 
                  : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
              }`}
            >
              <input
                type="radio"
                name="direction"
                value={dir}
                checked={filters.direction === dir}
                onChange={() => handleDirectionChange(dir as Direction | 'All')}
                className="mr-3 w-4 h-4 text-blue-600 focus:ring-2 focus:ring-blue-500"
              />
              <span className={`text-sm font-medium ${
                filters.direction === dir ? 'text-blue-900' : 'text-gray-700'
              }`}>
                {dir}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Segment/Station */}
      <div>
        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">
          Line Segment
        </label>
        <select
          value={filters.segment}
          onChange={(e) => handleSegmentChange(e.target.value)}
          className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl text-sm font-medium text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
        >
          <option value="All">All Segments</option>
          {SEGMENTS.map((segment) => (
            <option key={segment.id} value={segment.id}>
              {segment.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

